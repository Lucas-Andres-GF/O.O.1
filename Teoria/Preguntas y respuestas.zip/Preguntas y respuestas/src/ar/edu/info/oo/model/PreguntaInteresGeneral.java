package ar.edu.info.oo.model;

import java.util.Comparator;

public class PreguntaInteresGeneral extends Pregunta {

	public PreguntaInteresGeneral(String texto, Usuario autor) {
		super(texto, autor);
	}

	@Override
	public Respuesta mejorRespuesta() {
		// aqui algo huele mal
		return this.respuestas.stream().
				max(Comparator.comparingInt(Respuesta::diferenciaDeVotos)).
				orElse(null);

	}

}
