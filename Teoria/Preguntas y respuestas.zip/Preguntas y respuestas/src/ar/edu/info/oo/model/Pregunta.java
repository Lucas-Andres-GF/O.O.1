package ar.edu.info.oo.model;

import java.util.ArrayList;
import java.util.List;

public abstract class Pregunta extends Post {
	
	protected List<Respuesta> respuestas;
	
	public Pregunta(String texto, Usuario autor) {
		super(texto,autor);
		this.respuestas=new ArrayList<Respuesta>();
	}
	
	public abstract Respuesta mejorRespuesta();
	
	
	public boolean fueRespondida() {
		return this.respuestas.stream().anyMatch(r -> r.fueRespondida());
	}
	
	public void agregarRespuesta(Respuesta respuesta) {
		this.respuestas.add(respuesta);
	}

}
