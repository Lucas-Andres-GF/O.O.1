package ar.edu.info.oo.model;

public class Usuario {
	private String nombre;
	
	public Usuario(String nombre) {
		this.nombre=nombre;
	}

}
