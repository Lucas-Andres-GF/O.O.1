package ar.edu.info.oo.model;

import java.util.Comparator;

public class PreguntaTecnica extends Pregunta {
	
	public PreguntaTecnica(String texto, Usuario autor) {
		super(texto,autor);
	}
	
	public Respuesta mejorRespuesta() {
		// aqui algo huele mal
		return this.respuestas.stream().
				max(Comparator.comparing(Respuesta::adhesion)).
				orElse(null);
	}

	
	

}
