package ar.edu.info.oo.model;

public class Post {
	private String texto;
	private Usuario autor;
	
	public Post(String texto, Usuario autor) {
		this.texto= texto;
		this.autor=autor;
	}

}
